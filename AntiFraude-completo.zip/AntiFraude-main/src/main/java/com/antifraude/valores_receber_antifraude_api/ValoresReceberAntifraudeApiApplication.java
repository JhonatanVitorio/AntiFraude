package com.antifraude.valores_receber_antifraude_api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ValoresReceberAntifraudeApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(ValoresReceberAntifraudeApiApplication.class, args);
	}

}
