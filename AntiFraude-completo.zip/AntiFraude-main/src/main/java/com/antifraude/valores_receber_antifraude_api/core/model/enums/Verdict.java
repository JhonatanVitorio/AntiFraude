package com.antifraude.valores_receber_antifraude_api.core.model.enums;

public enum Verdict {
    SUSPECT,
    LEGIT,
    UNKNOWN
}
