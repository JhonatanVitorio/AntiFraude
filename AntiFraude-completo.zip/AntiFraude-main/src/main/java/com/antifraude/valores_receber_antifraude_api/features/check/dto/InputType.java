package com.antifraude.valores_receber_antifraude_api.features.check.dto;

public enum InputType {
    URL,
    TEXT,
    EMAIL
}
