package com.antifraude.valores_receber_antifraude_api.core.model.entity;

import jakarta.persistence.*;
import org.hibernate.annotations.CreationTimestamp;

import com.antifraude.valores_receber_antifraude_api.core.model.enums.Verdict;

import java.time.LocalDateTime;
import java.util.UUID;

@Entity
@Table(name = "url_record")
public class UrlRecord {

    @Id
    @GeneratedValue
    private UUID id;

    @Column(name = "normalized_url", nullable = false, length = 512)
    private String normalizedUrl;

    @Column(name = "domain", nullable = false, length = 255)
    private String domain;

    @CreationTimestamp
    @Column(name = "first_seen_at", updatable = false)
    private LocalDateTime firstSeenAt;

    @Column(name = "last_seen_at")
    private LocalDateTime lastSeenAt;

    @Enumerated(EnumType.STRING)
    @Column(name = "last_status", length = 10)
    private Verdict lastStatus;

    @Column(name = "last_score")
    private Integer lastScore;

    public UUID getId() {
        return id;
    }

    public String getNormalizedUrl() {
        return normalizedUrl;
    }

    public void setNormalizedUrl(String normalizedUrl) {
        this.normalizedUrl = normalizedUrl;
    }

    public String getDomain() {
        return domain;
    }

    public void setDomain(String domain) {
        this.domain = domain;
    }

    public LocalDateTime getFirstSeenAt() {
        return firstSeenAt;
    }

    public LocalDateTime getLastSeenAt() {
        return lastSeenAt;
    }

    public void setLastSeenAt(LocalDateTime lastSeenAt) {
        this.lastSeenAt = lastSeenAt;
    }

    public Verdict getLastStatus() {
        return lastStatus;
    }

    public void setLastStatus(Verdict lastStatus) {
        this.lastStatus = lastStatus;
    }

    public Integer getLastScore() {
        return lastScore;
    }

    public void setLastScore(Integer lastScore) {
        this.lastScore = lastScore;
    }
}
