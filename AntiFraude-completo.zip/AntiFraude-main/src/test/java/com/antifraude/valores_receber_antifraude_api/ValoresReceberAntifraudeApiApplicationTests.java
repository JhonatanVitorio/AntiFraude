package com.antifraude.valores_receber_antifraude_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ValoresReceberAntifraudeApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
