CREATE EXTENSION IF NOT EXISTS "pgcrypto";
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Tabela de histórico/cache de verificações
CREATE TABLE url_record (
  id CHAR(36) PRIMARY KEY DEFAULT (uuid_generate_v4()::text),
  normalized_url VARCHAR(512) NOT NULL UNIQUE,
  domain VARCHAR(255) NOT NULL,
  last_score INT CHECK (last_score BETWEEN 0 AND 100),
  last_status VARCHAR(10) CHECK (last_status IN ('LEGIT','SUSPECT','UNKNOWN')),
  last_seen_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Tabela de sites confiáveis (whitelist)
CREATE TABLE whitelist_entry (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  type VARCHAR(10) NOT NULL CHECK (type IN ('DOMAIN','URL')),
  entry_value VARCHAR(512) NOT NULL UNIQUE,
  active BOOLEAN NOT NULL DEFAULT TRUE,
  reason VARCHAR(255),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

-- Tabela de sites suspeitos (blacklist)
CREATE TABLE blacklist_entry (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  type VARCHAR(10) NOT NULL CHECK (type IN ('DOMAIN','URL')),
  entry_value VARCHAR(512) NOT NULL UNIQUE,
  active BOOLEAN NOT NULL DEFAULT TRUE,
  reason TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_urlrecord_domain ON url_record(domain);
CREATE INDEX idx_urlrecord_normalized ON url_record(normalized_url);
CREATE INDEX idx_whitelist_entry_value ON whitelist_entry(entry_value);
CREATE INDEX idx_blacklist_entry_value ON blacklist_entry(entry_value);

-- Dados de teste em url_record
INSERT INTO url_record (normalized_url, domain, last_score, last_status)
VALUES
('https://www.gov.br/receitafederal', 'gov.br', 5, 'LEGIT'),
('https://caixa-brasil.online/login', 'caixa-brasil.online', 95, 'SUSPECT');

-- dados de teste em whitelist_entry
INSERT INTO whitelist_entry (type, entry_value, reason)
VALUES
('DOMAIN', 'gov.br', 'Domínio oficial do governo brasileiro'),
('URL', 'https://www.caixa.gov.br', 'Site oficial da Caixa Econômica Federal');

-- dados de teste em blacklist_entry
INSERT INTO blacklist_entry (type, entry_value, reason)
VALUES
('DOMAIN', 'caixa-brasil.online', 'Domínio usado para phishing'),
('URL', 'https://beneficios-govbr.net/login', 'Página fraudulenta de benefícios');

SELECT * FROM blacklist_entry WHERE active = TRUE;